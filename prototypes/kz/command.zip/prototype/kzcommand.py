#!/usr/bin/env python

import optparse


def main():
    parser = optparse.OptionParser()
    parser.add_option('-p','--package', default='Default')
    options, args = parser.parse_args()



if __name__ == '__main__':
    main()