#!/usr/bin/env python

import os

def main():
    dirname = "[[%TEMP_PATH]]"
    oldfile = os.path.join( dirname, 'kzcommand.py' )
    newfile  = os.path.join( dirname, 'kz[[%PROJECT_NAME]].py' )
    os.rename( oldfile, newfile )


if __name__ == '__main__':
    main()
