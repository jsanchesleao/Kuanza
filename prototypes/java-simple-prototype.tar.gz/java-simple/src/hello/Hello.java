package hello;

import org.apache.log4j.Logger;
import org.apache.log4j.BasicConfigurator;

public class Hello{

	static final Logger log = Logger.getLogger(Hello.class);

	public static void main(String... args){
		BasicConfigurator.configure();
		log.info("Hello World");
	}
}
