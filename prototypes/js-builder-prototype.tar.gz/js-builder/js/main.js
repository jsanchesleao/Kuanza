/* main.js */
document.write("Hello World");
