package hello;

public class Hello implements HelloMBean{
	
	private String message;

	public Hello(){
		this.message = "Hello World!";
	}

	public Hello(String message){
		this.message = message;
	}

	public String getMessage(){
		return this.message;
	}	

	public void setMessage(String message){
		this.message = message;
	}	

	public void sayHello(){
		System.out.println(message);
	}

}
