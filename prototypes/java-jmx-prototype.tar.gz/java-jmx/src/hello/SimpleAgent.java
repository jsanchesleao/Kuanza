package hello;

import javax.management.*;
import java.lang.management.*;

public class SimpleAgent{

	private MBeanServer mbs = null;

	public SimpleAgent(){
		mbs = ManagementFactory.getPlatformMBeanServer();

		Hello helloBean = new Hello();
		ObjectName helloName = null;

		try{
			helloName = new ObjectName("FOO:name=helloBean");
			mbs.registerMBean(helloBean, helloName);
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}

	private static void waitForEnterPressed(){
		try{
			System.out.println("Press to continue");
			System.in.read();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public static void main(String... args){
		SimpleAgent agent = new SimpleAgent();
		System.out.println("SimpleAgent is running");
		SimpleAgent.waitForEnterPressed();
	}

}
