
var rest = require('../util/rest')
/*
 * GET home page.
 */

exports.index = rest.createService({

    "GET" : function( req ){
        return "OK"
    }


})