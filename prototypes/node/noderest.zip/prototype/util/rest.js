function createService(service){

    return function(req, res){

        method = req.method
        if( service[method] ){
            res.send( service[method](req) )
        }
        res.send('Not Found', 404)

    }

}

exports.createService = createService